from tkinter import *
import pandas
import random
import os
import sys
import subprocess

BACKGROUND_COLOR = "#89CFF0"
CORRECT_COLOR = "#b6d7a8"
INCORRECT_COLOR = "#f4cccc"

current_card = {}
to_learn = {}
flip_mode = "g2e"
streak_count = 0
selected_language = None

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

base_dir = os.path.dirname(os.path.abspath(__file__))
top_streak_file = os.path.join(base_dir, "top_streak.txt")
if os.path.exists(top_streak_file):
    with open(top_streak_file, "r") as file:
        top_streak = int(file.read().strip() or "0")
else:
    top_streak = 0

voice_map = {
    "French": "Microsoft Hortense Desktop",
    "German": "Microsoft Hedda Desktop",
    "Spanish": "Microsoft Sabina Desktop",
    "English": "Microsoft Zira Desktop"
}

def speak_word(text):
    voice_name = voice_map.get(selected_language, "Microsoft Zira Desktop")
    try:
        subprocess.call([
            'powershell', '-Command',
            f"Add-Type –AssemblyName System.Speech; "
            f"$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
            f"$speak.SelectVoice('{voice_name}'); "
            f"$speak.Speak('{text}')"
        ])
    except Exception as e:
        print(f"[TTS ERROR] {e}")

def load_language_csv(language):
    global to_learn
    language_files = {
        "German": "german_english_common.csv",
        "French": "french_english_common.csv",
        "Spanish": "spanish_english_common.csv"
    }
    filename = language_files.get(language)
    file_path = resource_path(os.path.join("data", filename))
    try:
        df = pandas.read_csv(file_path, encoding="utf-8-sig")
        df.columns = df.columns.str.strip()
        to_learn = df.to_dict(orient="records")
    except FileNotFoundError:
        raise Exception(f"CSV file not found: {file_path}")
    except Exception as e:
        raise Exception(f"Failed to load CSV: {e}")

def go_back_to_language_selection():
    try:
        mode_window.destroy()
    except:
        pass
    launch_language_selection()

def go_back_to_mode_selection():
    try:
        flash_window.destroy()
    except:
        pass
    open_mode_selection(selected_language)


def open_mode_selection(language):
    global selected_language, mode_window
    selected_language = language

    try:
        language_window.destroy()
    except:
        pass

    try:
        load_language_csv(language)
    except Exception as e:
        print(f"[ERROR] Failed to load CSV: {e}")
        return

    try:
        mode_window = Tk()
        mode_window.title(f"Select Mode - {language}")
        mode_window.config(padx=200, pady=200, bg=BACKGROUND_COLOR)
        label = Label(mode_window, text=f"Choose Mode ({language})", font=("Ariel", 24, "bold"), bg=BACKGROUND_COLOR)
        label.pack(pady=20)
        Button(mode_window, text=f"English → {language}", font=("Ariel", 16), width=25,
               command=lambda: launch_flashcard_ui("e2g")).pack(pady=10)
        Button(mode_window, text=f"{language} → English", font=("Ariel", 16), width=25,
               command=lambda: launch_flashcard_ui("g2e")).pack(pady=10)
        Button(mode_window, text="← Back to Language Selection", font=("Ariel", 12),
               command=go_back_to_language_selection).pack(pady=20)
        mode_window.mainloop()
    except Exception as e:
        print(f"[ERROR] open_mode_selection crash: {e}")

def launch_flashcard_ui(mode):
    global flip_mode, current_card, flash_window
    global streak_label, top_streak_label, placeholder_label
    flip_mode = mode
    mode_window.destroy()
    flash_window = Tk()
    flash_window.title("Magnus LC")
    flash_window.config(padx=50, pady=50, bg=BACKGROUND_COLOR)

    def flash_labels(color):
        labels = [streak_label, top_streak_label, feedback_label, instruction_label, placeholder_label]
        for lbl in labels:
            lbl.config(bg=color)
        flash_window.config(bg=color)
        canvas.config(bg=color)

    def next_card():
        global current_card
        labels = [streak_label, top_streak_label, feedback_label, instruction_label, placeholder_label]
        for lbl in labels:
            lbl.config(bg=BACKGROUND_COLOR)
        flash_window.config(bg=BACKGROUND_COLOR)
        canvas.config(bg=BACKGROUND_COLOR)

        current_card = random.choice(to_learn)
        question_lang = selected_language if flip_mode == "g2e" else "English"
        canvas.itemconfig(card_title, text=question_lang, fill="black")
        canvas.itemconfig(card_word, text=current_card[question_lang], fill="black")
        canvas.itemconfig(card_background, image=card_front_img)
        feedback_label.config(text="")
        entry.delete(0, END)

    def check_answer(event=None):
        global streak_count, top_streak
        user_input = entry.get().strip().lower()
        correct = current_card["English"].strip().lower() if flip_mode == "g2e" else current_card[selected_language].strip().lower()
        if user_input == correct:
            streak_count += 1
            if streak_count > top_streak:
                top_streak = streak_count
                with open(top_streak_file, "w") as file:
                    file.write(str(top_streak))
            streak_label.config(text=f"Words in a row: {streak_count}")
            top_streak_label.config(text=f"Top Streak: {top_streak}")
            feedback_label.config(text="Correct!", fg="green", bg=CORRECT_COLOR)
            flash_labels(CORRECT_COLOR)
            flash_window.after(700, next_card)
        else:
            streak_count = 0
            streak_label.config(text="Words in a row: 0")
            feedback_label.config(text="Incorrect!", fg="red", bg=INCORRECT_COLOR)
            flash_labels(INCORRECT_COLOR)
            answer_lang = "English" if flip_mode == "g2e" else selected_language
            canvas.itemconfig(card_title, text="Correct Answer", fill="white")
            canvas.itemconfig(card_word, text=current_card[answer_lang], fill="white")
            canvas.itemconfig(card_background, image=card_back_img)

    def on_hear_word():
        if current_card:
            # Determine the language of the word we're speaking
            if flip_mode == "g2e":
                word = current_card[selected_language]
                voice_lang = selected_language
            else:  # e2g
                word = current_card["English"]
                voice_lang = "English"
            voice_name = voice_map.get(voice_lang, "Microsoft Zira Desktop")
            try:
                subprocess.call([
                    'powershell', '-Command',
                    f"Add-Type –AssemblyName System.Speech; "
                    f"$speak = New-Object System.Speech.Synthesis.SpeechSynthesizer; "
                    f"$speak.SelectVoice('{voice_name}'); "
                    f"$speak.Speak('{word}')"
                ])
            except Exception as e:
                print(f"[TTS ERROR] {e}")

    canvas = Canvas(flash_window, width=800, height=526)
    card_front_img = PhotoImage(file=resource_path("images/card_front.png"))
    card_back_img = PhotoImage(file=resource_path("images/card_back.png"))
    cross_image = PhotoImage(file=resource_path("images/wrong.png"))
    card_background = canvas.create_image(400, 263, image=card_front_img)
    card_title = canvas.create_text(400, 150, text="", font=("Ariel", 40, "italic"))
    card_word = canvas.create_text(400, 263, text="", font=("Ariel", 60, "bold"))
    canvas.config(bg=BACKGROUND_COLOR, highlightthickness=0)
    canvas.grid(row=0, column=0, columnspan=2, pady=(0, 20))

    feedback_label = Label(text="", font=("Ariel", 20, "bold"), bg=BACKGROUND_COLOR)
    feedback_label.grid(row=1, column=0, columnspan=2)

    entry = Entry(width=30, font=("Ariel", 20))
    entry.grid(row=2, column=0, columnspan=2, pady=10)
    entry.bind("<Return>", check_answer)

    Button(text="Submit Answer", command=check_answer, font=("Ariel", 14)).grid(row=3, column=0, columnspan=2)

    instruction_label = Label(text="Press the 'X' button to skip the current word or incorrect answer", font=("Ariel", 14),
                              bg=BACKGROUND_COLOR, wraplength=300, justify="left")
    instruction_label.grid(row=4, column=0, sticky="e", padx=(0, 10), pady=10)

    Button(image=cross_image, highlightthickness=0, command=next_card).grid(row=4, column=1, pady=10)

    streak_label = Label(flash_window, text="Words in a row: 0", font=("Ariel", 14, "bold"), bg=BACKGROUND_COLOR)
    streak_label.place(x=10, y=-30)

    top_streak_label = Label(flash_window, text=f"Top Streak: {top_streak}", font=("Ariel", 14, "bold"), bg=BACKGROUND_COLOR)
    top_streak_label.place(x=330, y=-30)

    placeholder_label = Label(flash_window, text="Created by Drew Namirr", font=("Ariel", 14), bg=BACKGROUND_COLOR)
    placeholder_label.place(x=620, y=800)

    Button(flash_window, text="Hear Word", command=on_hear_word, font=("Ariel", 14)).place(x=10, y=593)
    Button(flash_window, text="← Back to Mode Selection", command=go_back_to_mode_selection,
           font=("Ariel", 14)).place(x=5, y=800)

    next_card()
    flash_window.mainloop()

def launch_language_selection():
    global language_window
    language_window = Tk()
    language_window.title("Select Language")
    language_window.config(padx=200, pady=200, bg=BACKGROUND_COLOR)
    Label(language_window, text="Choose a Language", font=("Ariel", 24, "bold"),
          bg=BACKGROUND_COLOR, pady=20).pack()
    Button(language_window, text="German", font=("Ariel", 16), width=20,
           command=lambda: open_mode_selection("German")).pack(pady=10)
    Button(language_window, text="French", font=("Ariel", 16), width=20,
           command=lambda: open_mode_selection("French")).pack(pady=10)
    Button(language_window, text="Spanish", font=("Ariel", 16), width=20,
           command=lambda: open_mode_selection("Spanish")).pack(pady=10)
    language_window.mainloop()

launch_language_selection()
